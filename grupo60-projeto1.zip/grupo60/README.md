# sd-project1

How to run all tests project:

 - make clean
 - make setup
 - make test_serial_run (this will run all tests at once (test_data, test_entry, test_tree and test_serialization) and show all the results)

How to run Valgrind:

 - make clean (if not done yet)
 - make setup (if not done yet)
 - make test_serial_run
 - valgrind --leak-check=full binary/test_data
 - valgrind --leak-check=full binary/test_entry
 - valgrind --leak-check=full binary/test_tree
 - valgrind --leak-check=full binary/test_serialization
